#-*- coding: utf8 -*-

__version__ = '1.3.4'
import GSMT, os
GSMT.main()
